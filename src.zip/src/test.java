class  test implements Comparable<test> {
    int x,y;
    public test (int x,int y){
        this.x=x;
        this.y=y;
    }
    public int compareTo(test t){
        if( x+y<t.x+t.y)return -1;
        return 1;
    }
}
