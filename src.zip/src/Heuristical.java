public class Heuristical {
   VertexSet H ;
    public  Heuristical (){
        VertexSet H= new VertexSet();
    }

    public  void GenerateInitAns(OriGraph G,Vertex q){
        //生成初始解H
    }
}
