import java.util.*;

public class Main {
    public static void main(String[] args) {
//    Set st0=new HashSet<Integer>();
//    for(int i=1;i<=5;i++){
//        st0.add(5-i);
//    }
//    Set<Integer> st=new TreeSet<Integer>(st0);
//        Iterator<Integer> it=st.iterator();

    }

}