public class UpperBoundingTechniques {

}
